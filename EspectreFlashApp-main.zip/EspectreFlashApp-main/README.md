# ESPectre Flash Tool

Web-based firmware flasher for [ESPectre](https://github.com/francescopace/espectre) — flash ESP32 devices directly from your browser using Chrome's Web Serial API.

## Usage

1. Open the tool in **Google Chrome**, **Microsoft Edge**, or **Brave** (version 89+)
2. Connect your ESP32 board via USB
3. Click **Connect** and select the serial port in the browser dialog
4. The tool auto-detects your chip (ESP32, ESP32-S3, ESP32-C6, etc.)
5. Choose a detection algorithm (MVS or ML)
6. Click **Flash Firmware** — the latest release is downloaded from GitHub and flashed directly

### After Flashing

Configure Wi-Fi using one of these methods:

- **BLE**: Use the ESPHome or Home Assistant Companion app
- **USB**: Go to [web.esphome.io](https://web.esphome.io) → Connect → Configure WiFi
- **Captive Portal**: Connect to the "ESPectre Fallback" WiFi network and configure in the browser

Home Assistant will auto-discover the device under **Settings → Devices & Services → ESPHome**.

## Supported Hardware

| Platform   | Status       | Notes                              |
|------------|-------------|-------------------------------------|
| ESP32-C6   | Tested      | WiFi 6 capable, compact             |
| ESP32-S3   | Tested      | Best for ML features (8MB PSRAM)    |
| ESP32-C3   | Tested      | Budget-friendly option               |
| ESP32-C5   | Tested      | WiFi 6 capable                      |
| ESP32      | Tested      | Original, no gain lock               |
| ESP32-S2   | Experimental| Limited testing                      |

## Detection Algorithms

- **MVS** (default) — Moving Variance Segmentation. Low CPU, adaptive threshold. Requires 10 seconds of stillness after boot for auto-calibration.
- **ML** (experimental) — Neural network (MLP 12→16→8→1). No calibration needed, fast boot (~3s). Pre-trained weights.

## CYD Waveform Display

CYD (Cheap Yellow Display) boards are ESP32 development boards that include a built-in TFT LCD screen and resistive touch panel. When running ESPectre firmware, the display provides a live visualization of CSI-based motion detection without needing a browser or Home Assistant.

### What the Display Shows

- **Real-time scrolling waveform** of CSI movement intensity, drawn left-to-right and wrapping when it reaches the edge
- **Threshold dashed line** overlaid on the waveform, showing the current detection boundary
- **MOTION / IDLE state indicator** in the top-right corner, color-coded (red for motion, green for idle)
- **Numeric values** for the current movement score and threshold printed on screen

### Touch Interaction

The touch screen is divided into two zones:

- **Tap the left half** of the screen to **decrease** the detection threshold
- **Tap the right half** of the screen to **increase** the detection threshold

This lets you tune sensitivity on the device itself, without editing configuration files.

### Supported CYD Boards

| Board | Display | Resolution | Touch |
|-------|---------|------------|-------|
| ESP32-2432S028R (CYD 2.8") | ILI9341 | 320x240 | XPT2046 resistive |
| ESP32-3248S035R (CYD 3.5") | ST7796 | 480x320 | XPT2046 resistive |

> **Note:** CYD boards use the original ESP32 chip and will be auto-detected as "ESP32" by the flash tool. After detection, select the appropriate CYD variant from the board selector to flash the correct firmware with display and touch support.

### Building CYD Firmware from Source

If you want to customize the display layout, touch behavior, or detection parameters, you can compile the CYD firmware yourself:

```bash
cd firmware
source ../espectre/venv/bin/activate  # or your ESPHome venv
esphome compile espectre-cyd-28.yaml
```

### Touch Calibration

Touch coordinates may vary between individual boards and display batches. If taps are registering in the wrong position, adjust the calibration values (`x_min`, `x_max`, `y_min`, `y_max`) in the touchscreen section of the YAML configuration file for your board.

## Browser Requirements

The [Web Serial API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Serial_API) is required. Supported browsers:

- Google Chrome 89+
- Microsoft Edge 89+
- Brave 89+
- Opera 76+

**Not supported**: Firefox, Safari.

## Troubleshooting

### Board not detected

1. Hold the **BOOT** button on the ESP32
2. Press and release the **RESET** button
3. Release **BOOT**
4. Click Connect again

### ESP32-C3 Super Mini issues

- If using a board with an external USB-UART bridge (CH340, CP2102), the chip may still be detected but may need `hardware_uart: UART0` in the ESPHome config for logs after flashing.
- Set traffic generator rate to 94 or lower for C3 boards.

### Flash fails or hangs

- Try a different USB cable (some cables are charge-only with no data lines)
- Try a different USB port
- Make sure no other application (Arduino IDE, ESPHome, serial monitor) is using the port

## Hosting

This is a static site with no build step. To run locally:

```bash
python3 -m http.server 8000
# Open http://localhost:8000
```

Or deploy to GitHub Pages — enable it under the repo's Settings → Pages → Deploy from branch (main).

## Technology

- [Web Serial API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Serial_API) for USB communication
- [esptool-js](https://github.com/espressif/esptool-js) for ESP32 flash protocol
- Firmware binaries fetched from [ESPectre GitHub Releases](https://github.com/francescopace/espectre/releases)

## License

MIT
