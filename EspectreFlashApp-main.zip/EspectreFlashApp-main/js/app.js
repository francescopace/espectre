const GITHUB_REPO = "francescopace/espectre";
const SUPPORTED_CHIPS = {
  "ESP32":    "esp32",
  "ESP32-S2": "esp32s2",
  "ESP32-S3": "esp32s3",
  "ESP32-C3": "esp32c3",
  "ESP32-C5": "esp32c5",
  "ESP32-C6": "esp32c6",
};

const CYD_BOARDS = {
  "cyd28": { file: "firmware/espectre-cyd-28.bin", display: "ILI9341 320x240" },
  "cyd35": { file: "firmware/espectre-cyd-35.bin", display: "ST7796 480x320" },
};

const CHIP_KEYS_BY_LENGTH = Object.keys(SUPPORTED_CHIPS).sort(
  (a, b) => b.length - a.length
);

let port = null;
let transport = null;
let esploader = null;
let releaseData = null;
let detectedChipKey = null;
let selectedCydBoard = null;
let manualFirmware = null;

const $ = (id) => document.getElementById(id);

const terminal = $("terminal");

function log(msg) {
  const ts = new Date().toLocaleTimeString();
  terminal.textContent += `[${ts}] ${msg}\n`;
  terminal.scrollTop = terminal.scrollHeight;
}

function logError(msg) {
  log(`ERROR: ${msg}`);
}

const espTerminal = {
  clean() {},
  writeLine(data) { log(data); },
  write(data) {
    terminal.textContent += data;
    terminal.scrollTop = terminal.scrollHeight;
  },
};

function show(el) {
  if (typeof el === "string") el = $(el);
  el.classList.remove("hidden");
}

function hide(el) {
  if (typeof el === "string") el = $(el);
  el.classList.add("hidden");
}

function setProgress(pct) {
  $("progress-fill").style.width = `${pct}%`;
  $("progress-text").textContent = `${pct}%`;
  const bar = $("progress-fill").parentElement;
  bar.setAttribute("aria-valuenow", pct);
}

function checkBrowserSupport() {
  if (!("serial" in navigator)) {
    show("browser-warning");
    return false;
  }
  show("app");
  return true;
}

async function fetchLatestRelease() {
  log("Fetching latest ESPectre release...");
  try {
    const resp = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/releases/latest`);
    if (!resp.ok) throw new Error(`GitHub API returned ${resp.status}`);
    releaseData = await resp.json();
    log(`Latest release: ${releaseData.tag_name}`);
    return releaseData;
  } catch (err) {
    logError(`Failed to fetch release info: ${err.message}`);
    return null;
  }
}

function getFirmwareAsset(chipKey, algorithm) {
  if (!releaseData) return null;
  const chipSlug = SUPPORTED_CHIPS[chipKey];
  if (!chipSlug) return null;

  const suffix = algorithm === "ml" ? "-ml" : "";
  const pattern = `espectre-${releaseData.tag_name}-${chipSlug}${suffix}.bin`;

  return releaseData.assets.find((a) => a.name === pattern) || null;
}

function updateFirmwareInfo() {
  const boardValue = $("select-board") ? $("select-board").value : "standard";
  selectedCydBoard = (boardValue !== "standard" && CYD_BOARDS[boardValue]) ? boardValue : null;

  // Hide algorithm selector for CYD boards (always MVS)
  if (selectedCydBoard) {
    hide("algorithm-group");
  } else {
    show("algorithm-group");
  }

  if (selectedCydBoard) {
    const cyd = CYD_BOARDS[selectedCydBoard];
    $("fw-version").textContent = "custom build";
    $("fw-file").textContent = cyd.file;
    $("btn-flash").disabled = false;

    $("algo-help").textContent =
      "CYD firmware uses MVS with built-in waveform display. No algorithm selection needed.";
  } else {
    const algo = $("select-algorithm").value;
    const asset = getFirmwareAsset(detectedChipKey, algo);

    $("fw-version").textContent = releaseData ? releaseData.tag_name : "--";
    $("fw-file").textContent = asset ? asset.name : "Not available";
    $("btn-flash").disabled = !asset && !manualFirmware;

    if (algo === "ml") {
      $("algo-help").textContent =
        "ML uses a neural network (MLP 12→16→8→1). No calibration needed, fast boot (~3s). Experimental.";
    } else {
      $("algo-help").textContent =
        "MVS uses adaptive variance-based detection. Requires 10 seconds of stillness after boot for calibration.";
    }
  }

  manualFirmware = null;
  $("fw-manual").textContent = "";
  hide("manual-upload");
}

function detectChip(chipName) {
  return CHIP_KEYS_BY_LENGTH.find(
    (k) => chipName.toUpperCase().includes(k.toUpperCase())
  ) || null;
}

async function connectDevice() {
  try {
    $("btn-connect").disabled = true;
    log("Requesting serial port...");
    port = await navigator.serial.requestPort();

    log("Loading esptool-js...");
    const esptoolMod = await import(
      "https://unpkg.com/esptool-js@0.5.4/bundle.js"
    );
    const Transport = esptoolMod.Transport;
    const ESPLoader = esptoolMod.ESPLoader;

    log("Opening serial connection...");
    transport = new Transport(port, true);

    esploader = new ESPLoader({
      transport,
      baudrate: 115200,
      terminal: espTerminal,
      romBaudrate: 115200,
    });

    log("Connecting to chip (hold BOOT button if it hangs)...");
    const chipName = await esploader.main();
    log(`Chip detected: ${chipName}`);

    detectedChipKey = detectChip(chipName);

    $("chip-name").textContent = chipName;
    try {
      const mac = await esploader.chip.readMac(esploader);
      $("chip-mac").textContent = mac;
    } catch {
      $("chip-mac").textContent = "N/A";
    }

    try {
      const flashSize = await esploader.getFlashSize();
      $("chip-flash").textContent = flashSize ? `${flashSize / 1024} MB` : "Unknown";
    } catch {
      $("chip-flash").textContent = "Unknown";
    }

    show("step-chip");
    show("btn-disconnect");

    if (detectedChipKey && SUPPORTED_CHIPS[detectedChipKey]) {
      hide("chip-unsupported");
      if (detectedChipKey === "ESP32") {
        show("board-selector");
      } else {
        hide("board-selector");
      }
      await fetchLatestRelease();
      updateFirmwareInfo();
      show("step-config");
      log(`Ready to flash ${detectedChipKey}`);
    } else {
      show("chip-unsupported");
      logError(`Chip "${chipName}" is not supported by ESPectre`);
    }
  } catch (err) {
    if (err.name === "NotFoundError") {
      log("No port selected.");
    } else {
      logError(`Connection failed: ${err.message}`);
    }
    await cleanup();
  } finally {
    $("btn-connect").disabled = false;
  }
}

async function disconnectDevice() {
  log("Disconnecting...");
  await cleanup();
  hide("step-chip");
  hide("step-config");
  hide("step-flash");
  hide("step-done");
  hide("btn-disconnect");
  hide("board-selector");
  selectedCydBoard = null;
  log("Disconnected.");
}

async function cleanup() {
  esploader = null;
  detectedChipKey = null;
  selectedCydBoard = null;
  manualFirmware = null;

  if (transport) {
    try { await transport.disconnect(); } catch {}
    transport = null;
  }
  port = null;
}

function arrayBufferToBinaryString(buffer) {
  const bytes = new Uint8Array(buffer);
  let binaryString = "";
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
    binaryString += String.fromCharCode.apply(null, chunk);
  }
  return binaryString;
}

async function downloadFirmware(asset) {
  log(`Downloading ${asset.name} (${(asset.size / 1024).toFixed(0)} KB)...`);

  try {
    const resp = await fetch(asset.browser_download_url);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const buf = await resp.arrayBuffer();
    log(`Firmware downloaded: ${buf.byteLength} bytes`);
    return buf;
  } catch (directErr) {
    log(`Direct download failed (${directErr.message}), trying CORS proxy...`);
  }

  try {
    const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(asset.browser_download_url)}`;
    const resp = await fetch(proxyUrl);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const buf = await resp.arrayBuffer();
    log(`Firmware downloaded via proxy: ${buf.byteLength} bytes`);
    return buf;
  } catch (proxyErr) {
    log(`Proxy download also failed (${proxyErr.message}).`);
  }

  log("Automatic download unavailable. Please download the file manually.");
  const downloadUrl = `https://github.com/${GITHUB_REPO}/releases/download/${releaseData.tag_name}/${asset.name}`;
  $("manual-download-link").href = downloadUrl;
  $("manual-download-link").textContent = asset.name;
  show("manual-upload");

  return new Promise((resolve, reject) => {
    const input = $("file-input");
    const handler = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      input.removeEventListener("change", handler);
      log(`Manual file selected: ${file.name} (${file.size} bytes)`);
      $("fw-manual").textContent = file.name;
      file.arrayBuffer().then(resolve).catch(reject);
    };
    input.addEventListener("change", handler);
  });
}

async function flashFirmware() {
  const isCyd = !!selectedCydBoard;
  const algo = $("select-algorithm").value;
  const asset = isCyd ? null : getFirmwareAsset(detectedChipKey, algo);
  if (!isCyd && !asset && !manualFirmware) {
    logError("No firmware asset found.");
    return;
  }

  $("btn-flash").disabled = true;
  $("btn-disconnect").disabled = true;
  show("step-flash");
  $("step-flash").classList.add("flashing");
  $("flash-status").textContent = "Downloading firmware...";
  setProgress(0);

  try {
    let firmwareBuffer;
    if (isCyd) {
      const cyd = CYD_BOARDS[selectedCydBoard];
      log(`Downloading CYD firmware: ${cyd.file}...`);
      const resp = await fetch(cyd.file);
      if (!resp.ok) throw new Error(`Failed to fetch ${cyd.file}: HTTP ${resp.status}`);
      firmwareBuffer = await resp.arrayBuffer();
      log(`CYD firmware downloaded: ${firmwareBuffer.byteLength} bytes`);
    } else if (manualFirmware) {
      firmwareBuffer = manualFirmware;
    } else {
      firmwareBuffer = await downloadFirmware(asset);
    }

    const binaryString = arrayBufferToBinaryString(firmwareBuffer);

    $("flash-status").textContent = "Erasing flash...";
    log("Starting flash (this takes 1-2 minutes)...");
    $("flash-status").textContent = "Writing firmware...";

    const flashOptions = {
      fileArray: [{ data: binaryString, address: 0x0 }],
      flashSize: "keep",
      flashMode: "keep",
      flashFreq: "keep",
      eraseAll: false,
      compress: true,
      reportProgress(fileIndex, written, total) {
        const pct = Math.round((written / total) * 100);
        setProgress(pct);
      },
      calculateMD5Hash: (image) => undefined,
    };

    await esploader.writeFlash(flashOptions);

    log("Flash complete!");
    setProgress(100);
    $("flash-status").textContent = "Done!";
    $("step-flash").classList.remove("flashing");

    log("Resetting device...");
    try {
      await esploader.after("hard_reset");
    } catch {
      log("Hard reset not available; please unplug and replug the device.");
    }

    show("step-done");
    log("Device is ready. Configure Wi-Fi to complete setup.");
  } catch (err) {
    logError(`Flash failed: ${err.message}`);
    $("flash-status").textContent = `Failed: ${err.message}`;
    $("step-flash").classList.remove("flashing");
    $("btn-flash").disabled = false;
  } finally {
    $("btn-disconnect").disabled = false;
  }
}

async function resetApp() {
  hide("step-chip");
  hide("step-config");
  hide("step-flash");
  hide("step-done");
  hide("btn-disconnect");
  hide("manual-upload");
  hide("board-selector");
  selectedCydBoard = null;
  $("step-flash").classList.remove("flashing");
  setProgress(0);
  $("btn-flash").disabled = false;
  $("btn-connect").disabled = false;
  manualFirmware = null;
  await cleanup();
  log("Ready to flash another device.");
}

function init() {
  if (!checkBrowserSupport()) return;

  $("btn-connect").addEventListener("click", connectDevice);
  $("btn-disconnect").addEventListener("click", disconnectDevice);
  $("btn-flash").addEventListener("click", flashFirmware);
  $("btn-restart").addEventListener("click", resetApp);
  $("btn-clear-log").addEventListener("click", () => {
    terminal.textContent = "";
  });

  $("select-algorithm").addEventListener("change", updateFirmwareInfo);
  $("select-board").addEventListener("change", updateFirmwareInfo);

  log("ESPectre Flash Tool ready.");
  log("Connect your ESP32 via USB and click Connect.");
}

init();
